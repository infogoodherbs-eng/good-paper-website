# Good Paper Website

This is a free, static website for Good Paper by Good Herbs Enterprises.

## Publish for free with GitHub Pages
1. Create/sign in to a GitHub account.
2. Create a new public repository, e.g. `good-paper-website`.
3. Upload `index.html`, `style.css`, and `script.js`.
4. Open Settings → Pages.
5. Select Deploy from branch → `main` → `/ (root)`.
6. GitHub will provide your free website address.

## Contact details included
Hero Homes, Sector 88, Mohali, Punjab - 160055
8527449449
goodherbs@gmail.com

The WhatsApp buttons already open a chat to +91 8527449449.
